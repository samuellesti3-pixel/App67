use std::path::PathBuf;
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};

use reqwest::Client;

use crate::downloaders;
use crate::models::{AlbumYear, DownloadConfig, Service, SkipConfig, Track};

#[expect(
    clippy::too_many_arguments,
    reason = "this function is called from a single place"
)]
pub async fn run_album_worker(
    client: Client,
    urls: Arc<Mutex<Vec<String>>>,
    output_path: PathBuf,
    force_download: bool,
    group_singles: bool,
    album_year: Option<AlbumYear>,
    flatten_directories: bool,
    config: DownloadConfig,
    track_workers: usize,
    skip: SkipConfig,
    running: Arc<AtomicBool>,
) {
    while running.load(Ordering::Relaxed) {
        let Some(url) = urls.lock().unwrap().pop() else {
            tracing::info!("stopped: no queued albums");
            return;
        };

        downloaders::download_album(
            client.clone(),
            &url,
            &output_path,
            force_download,
            group_singles,
            album_year,
            flatten_directories,
            config.clone(),
            track_workers,
            skip,
            running.clone(),
        )
        .await;
    }

    tracing::info!("stopped");
}

#[expect(clippy::type_complexity)]
#[expect(
    clippy::too_many_arguments,
    reason = "this function is called from a single place"
)]
pub async fn run_track_worker(
    client: Client,
    service: Service,
    tracks: Arc<Mutex<Vec<(Option<u32>, Track)>>>,
    track_count: u32,
    is_grouped_single: bool,
    token_expiry: u64,
    force_download: bool,
    config: DownloadConfig,
    album_path: Arc<PathBuf>,
    running: Arc<AtomicBool>,
) {
    while running.load(Ordering::Relaxed) {
        let Some((track_number, track)) = tracks.lock().unwrap().pop() else {
            return;
        };

        downloaders::request_and_download_track(
            client.clone(),
            service,
            &track,
            track_number,
            track_count,
            is_grouped_single,
            token_expiry,
            force_download,
            &config,
            album_path.clone(),
            running.clone(),
        )
        .await;
    }
}
