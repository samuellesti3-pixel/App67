use std::borrow::Cow;
use std::path::{Path, PathBuf};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::{Arc, Mutex};
use std::time::{Duration, Instant};

use futures::future;
use reqwest::Client;
use tokio::fs::File;
use tokio::io::{AsyncWriteExt, BufWriter};
use tokio::{fs, time};
use tracing::Instrument;

use crate::models::{
    AlbumInfo, AlbumYear, DownloadConfig, PageData, ResolveAlbumError, Service, SkipConfig, Track,
    TrackDownload,
};
use crate::{requests, text_utils, workers};

struct DownloadError;

#[expect(
    clippy::too_many_arguments,
    reason = "this function is called from a single place"
)]
pub async fn download_album(
    client: Client,
    url: &str,
    output_path: &Path,
    force_download: bool,
    group_singles: bool,
    album_year: Option<AlbumYear>,
    flatten_directories: bool,
    config: DownloadConfig,
    track_workers: usize,
    skip: SkipConfig,
    running: Arc<AtomicBool>,
) {
    let Some(page_data) = resolve_album(&client, url, &config, &running).await else {
        return;
    };

    let album = match AlbumInfo::new(page_data.info, page_data.token) {
        Ok(album) => album,
        Err(err) => {
            match err {
                ResolveAlbumError::ArtistUrl { name } => {
                    tracing::error!("cannot download URL pointing to an artist ({name})");
                }
            }

            return;
        }
    };

    tracing::info!(
        "downloading album {} - {} with {} tracks",
        album.artist_name,
        album.title,
        album.track_count
    );

    let is_grouped_single = group_singles
        && album.track_count == 1
        && album
            .tracks
            .iter()
            .all(|track| track.1.title == album.title);

    let album_path = {
        let sanitized_artist_name = text_utils::sanitize_file_name(&album.artist_name);

        let album_directory = if is_grouped_single {
            "Singles".into()
        } else {
            let sanitized_album_title = text_utils::sanitize_file_name(&album.title);

            match (album.release_year, album_year) {
                (Some(release_year), Some(AlbumYear::Append)) => {
                    format!("{sanitized_album_title} ({release_year})")
                }
                (Some(release_year), Some(AlbumYear::Prepend)) => {
                    format!("({release_year}) {sanitized_album_title}")
                }
                _ => sanitized_album_title,
            }
        };

        let album_directory = if flatten_directories {
            vec![format!("{sanitized_artist_name} - {album_directory}")]
        } else {
            vec![sanitized_artist_name, album_directory]
        };

        let mut album_path = PathBuf::from(output_path);
        album_path.extend(album_directory);

        album_path
    };

    fs::create_dir_all(&album_path).await.unwrap();

    let tracks_len = album.tracks.len();
    let tracks = Arc::new(Mutex::new(album.tracks));
    let album_path = Arc::new(album_path);

    if !skip.tracks {
        let worker_count = track_workers.min(tracks_len);

        tracing::info!("spawning {worker_count} track workers");

        for result in future::join_all((1..=worker_count).map(|track_worker| {
            tokio::spawn(
                workers::run_track_worker(
                    client.clone(),
                    page_data.original_service,
                    tracks.clone(),
                    album.track_count,
                    is_grouped_single,
                    page_data.token_expiry,
                    force_download,
                    config.clone(),
                    album_path.clone(),
                    running.clone(),
                )
                .instrument(tracing::info_span!("track", track_worker)),
            )
        }))
        .await
        {
            result.unwrap();
        }
    }

    if skip.cover || is_grouped_single || !running.load(Ordering::Relaxed) {
        return;
    }

    download_album_cover(
        client,
        &album.title,
        page_data.original_service,
        &album.cover_artwork_url,
        force_download,
        &album_path,
        running,
    )
    .await;
}

async fn resolve_album(
    client: &Client,
    url: &str,
    config: &DownloadConfig,
    running: &Arc<AtomicBool>,
) -> Option<PageData> {
    tracing::info!("resolving album {url}");

    let html = loop {
        let html = requests::resolve_album(client, url, &config.country, running).await?;

        if let Some(error) = [
            "An error occured trying to process your request.",
            "Message: \"Cannot contact any valid server\"",
            "An error occurred. Had an issue getting that item, try again.",
        ]
        .into_iter()
        .find(|&error| html.contains(error))
        {
            tracing::warn!("HTML contains error: {error}");

            if !running.load(Ordering::Relaxed) {
                return None;
            }

            time::sleep(Duration::from_secs(5)).await;
        } else {
            break html;
        }
    };

    Some(
        json5::from_str(text_utils::parse_enclosed_value(
            ",{\"type\":\"data\",\"data\":",
            ",\"uses\":{\"url\":1}}];\n",
            &html,
        ))
        .unwrap(),
    )
}

#[expect(
    clippy::too_many_arguments,
    reason = "this function is called from a single place"
)]
pub async fn request_and_download_track(
    client: Client,
    service: Service,
    track: &Track,
    track_number: Option<u32>,
    track_count: u32,
    is_grouped_single: bool,
    token_expiry: u64,
    force_download: bool,
    config: &DownloadConfig,
    album_path: Arc<PathBuf>,
    running: Arc<AtomicBool>,
) {
    // HACK(jel): this seems to be the only way to detect tracks that are impossible
    // to download yet
    if matches!(service, Service::Qobuz if track.producers.is_none()) {
        tracing::error!("skipping unavailable track {}", track.title);
        return;
    }

    let file_stem =
        text_utils::format_track_stem(track, track_number, track_count, is_grouped_single);

    if !force_download {
        let mut directory = fs::read_dir(album_path.as_path()).await.unwrap();

        while let Some(entry) = directory.next_entry().await.unwrap() {
            if entry.file_type().await.unwrap().is_file()
                && entry
                    .path()
                    .file_stem()
                    .is_some_and(|stem| stem.to_str().unwrap() == file_stem)
            {
                tracing::info!("track {} is already downloaded", track.title);
                return;
            }
        }
    }

    tracing::info!("downloading track {}", track.title);

    request_track_download(
        client,
        track,
        &file_stem,
        token_expiry,
        config,
        album_path,
        running,
    )
    .await;
}

async fn request_track_download(
    client: Client,
    track: &Track,
    file_stem: &str,
    token_expiry: u64,
    config: &DownloadConfig,
    album_path: Arc<PathBuf>,
    running: Arc<AtomicBool>,
) {
    'request_track_download: loop {
        let Some(track_download) =
            requests::request_track_download(&client, track, token_expiry, config, running.clone())
                .await
        else {
            break;
        };

        let mut last_status: Option<(String, String, Instant)> = None;

        loop {
            let Some(track_download) =
                requests::track_download_status(&client, &track_download).await
            else {
                if !running.load(Ordering::Relaxed) {
                    return;
                }

                continue 'request_track_download;
            };

            if last_status.as_ref().is_none_or(|last_status| {
                (&track_download.status, &track_download.message)
                    != (&last_status.0, &last_status.1)
            }) {
                tracing::info!(
                    "new download status: {}: {}",
                    track_download.status,
                    track_download.message.replace("{item}", &track.title)
                );

                last_status = Some((
                    track_download.status.clone(),
                    track_download.message,
                    Instant::now(),
                ));
            } else if let Some(last_status) = last_status.as_ref()
                && last_status.2.elapsed() >= Duration::from_secs(30)
            {
                let is_running = running.load(Ordering::Relaxed);

                tracing::warn!(
                    "download status stuck for 30 seconds on {}: {}{}",
                    last_status.0,
                    last_status.1.replace("{item}", &track.title),
                    if is_running { ", retrying" } else { "" }
                );

                if !is_running {
                    return;
                }

                continue 'request_track_download;
            }

            if track_download.status == "completed" {
                break;
            }

            time::sleep(Duration::from_secs(1)).await;
        }

        let Ok(()) = download_track(
            client.clone(),
            track_download,
            album_path.clone(),
            file_stem,
            running.clone(),
        )
        .await
        else {
            continue 'request_track_download;
        };

        break;
    }
}

async fn download_track(
    client: Client,
    track_download: TrackDownload,
    album_path: Arc<PathBuf>,
    file_stem: &str,
    running: Arc<AtomicBool>,
) -> Result<(), DownloadError> {
    'download_track: loop {
        let Some((mut rx, mime_type)) = requests::download_track(&client, &track_download).await
        else {
            if !running.load(Ordering::Relaxed) {
                break Ok(());
            }

            break Err(DownloadError);
        };

        let file_extension = match mime_type
            .split_once(';')
            .map_or(mime_type.as_str(), |(mime_type, _)| mime_type)
        {
            "audio/flac" => "flac",
            "audio/mpeg" => "mp3",
            "audio/mp4" => "m4a",
            _ => panic!("unsupported mime type {mime_type}"),
        };

        let file_name = format!("{file_stem}.{file_extension}");
        let part_path = album_path.join(format!("{file_name}.part"));
        let mut file = BufWriter::new(File::create(&part_path).await.unwrap());

        while let Some(result) = rx.recv().await {
            match result {
                Ok(chunk) => file.write_all(&chunk).await.unwrap(),
                Err(()) => continue 'download_track,
            }
        }

        fs::rename(part_path, album_path.join(file_name))
            .await
            .unwrap();

        break Ok(());
    }
}

pub async fn download_album_cover(
    client: Client,
    title: &str,
    service: Service,
    url: &str,
    force_download: bool,
    album_path: &Path,
    running: Arc<AtomicBool>,
) {
    let cover_path = album_path.join("cover.jpg");

    if !force_download && cover_path.exists() {
        tracing::info!("{title} album cover is already downloaded");
        return;
    }

    tracing::info!("downloading {title} album cover");

    let url = match service {
        Service::Qobuz => {
            let stripped_url = url.strip_suffix(".jpg").unwrap();
            let end_index = stripped_url.rfind('_').unwrap() + 1;
            Cow::Owned(format!("{}org.jpg", &url[..end_index]))
        }
        Service::Tidal | Service::Soundcloud | Service::Amazon => Cow::Borrowed(url),
    };

    let part_path = album_path.join("cover.jpg.part");

    'download_album_cover: loop {
        let Some(mut rx) = requests::download_album_cover(&client, &url, running.clone()).await
        else {
            return;
        };

        let mut file = BufWriter::new(File::create(&part_path).await.unwrap());

        while let Some(chunk) = rx.recv().await {
            if let Ok(chunk) = chunk {
                file.write_all(&chunk).await.unwrap();
            } else {
                if !running.load(Ordering::Relaxed) {
                    return;
                }

                continue 'download_album_cover;
            }
        }

        file.flush().await.unwrap();
        break;
    }

    fs::rename(part_path, cover_path).await.unwrap();
}
