use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

use reqwest::header::CONTENT_TYPE;
use reqwest::{Client, StatusCode, Url};
use tokio::sync::mpsc::{self, UnboundedReceiver};
use tokio::time;
use tracing::Instrument;

use crate::models::{
    Account, Availability, DownloadConfig, Token, Track, TrackDownload, TrackDownloadRequest,
    TrackDownloadResult, TrackDownloadStatus, Upload,
};

const IRRECOVERABLE_STATUS_CODES: [StatusCode; 2] =
    [StatusCode::NOT_FOUND, StatusCode::INTERNAL_SERVER_ERROR];

pub async fn check_availability(client: &Client) -> Availability {
    let response = client.get("https://lucida.to/").send().await.unwrap();

    match response.status() {
        StatusCode::OK => Availability::Available,
        StatusCode::FORBIDDEN => Availability::Captcha,
        _ => Availability::Unavailable,
    }
}

pub async fn resolve_album(
    client: &Client,
    url: &str,
    country: &str,
    running: &Arc<AtomicBool>,
) -> Option<String> {
    loop {
        let response = client
            .get(
                Url::parse_with_params("https://lucida.to/", &[("url", url), ("country", country)])
                    .unwrap(),
            )
            .send()
            .await
            .unwrap();

        let status = response.status();

        if status == StatusCode::OK {
            break Some(response.text().await.unwrap());
        }

        tracing::warn!("received code {} when resolving album", status.as_u16());

        if !running.load(Ordering::Relaxed) {
            break None;
        }

        time::sleep(Duration::from_secs(5)).await;
    }
}

pub async fn request_track_download(
    client: &Client,
    track: &Track,
    token_expiry: u64,
    config: &DownloadConfig,
    running: Arc<AtomicBool>,
) -> Option<TrackDownload> {
    loop {
        let response = client
            .post("https://lucida.to/api/load?url=%2Fapi%2Ffetch%2Fstream%2Fv2")
            .json(&TrackDownloadRequest {
                account: Account {
                    id: &config.country,
                    r#type: "country",
                },
                compat: false,
                downscale: "original",
                handoff: true,
                metadata: config.metadata,
                private: config.private,
                token: Token {
                    expiry: token_expiry,
                    primary: track.csrf.as_deref(),
                    secondary: track.csrf_fallback.as_deref(),
                },
                upload: Upload { enabled: false },
                url: &track.url,
            })
            .send()
            .await
            .unwrap();

        let status = response.status();

        if status == StatusCode::OK {
            if let Ok(track_download) = response.json().await {
                match track_download {
                    TrackDownloadResult::Ok(track_download) => break Some(track_download),
                    TrackDownloadResult::Error { error, .. } => {
                        tracing::warn!("error when requesting track download: {error}");

                        if !running.load(Ordering::Relaxed) {
                            break None;
                        }

                        time::sleep(Duration::from_secs(5)).await;
                    }
                }
            } else {
                tracing::warn!("invalid JSON when requesting track download");

                if !running.load(Ordering::Relaxed) {
                    break None;
                }

                time::sleep(Duration::from_secs(5)).await;
            }
        } else {
            tracing::warn!(
                "received code {} when requesting track download",
                status.as_u16()
            );

            if !running.load(Ordering::Relaxed) {
                break None;
            }

            time::sleep(Duration::from_secs(5)).await;
        }
    }
}

pub async fn track_download_status(
    client: &Client,
    stream: &TrackDownload,
) -> Option<TrackDownloadStatus> {
    loop {
        let response = client
            .get(format!(
                "https://{}.lucida.to/api/fetch/request/{}",
                stream.server, stream.handoff
            ))
            .send()
            .await
            .unwrap();

        let status = response.status();

        if status == StatusCode::OK {
            break Some(response.json().await.unwrap());
        }

        tracing::warn!(
            "received code {} when checking track processing status",
            status.as_u16()
        );

        if IRRECOVERABLE_STATUS_CODES.contains(&status) {
            break None;
        }

        time::sleep(Duration::from_secs(5)).await;
    }
}

pub async fn download_track(
    client: &Client,
    stream: &TrackDownload,
) -> Option<(UnboundedReceiver<Result<Vec<u8>, ()>>, String)> {
    loop {
        let mut response = client
            .get(format!(
                "https://{}.lucida.to/api/fetch/request/{}/download",
                stream.server, stream.handoff
            ))
            .send()
            .await
            .unwrap();

        let status = response.status();

        if status == StatusCode::OK {
            let mime_type = response.headers()[CONTENT_TYPE]
                .to_str()
                .unwrap()
                .to_owned();

            let (tx, rx) = mpsc::unbounded_channel();

            tokio::spawn(
                async move {
                    loop {
                        let result = response.chunk().await;

                        match result {
                            Ok(chunk) => match chunk {
                                Some(chunk) => tx.send(Ok(chunk.to_vec())).unwrap(),
                                None => break,
                            },
                            Err(err) => {
                                tracing::warn!("error when downloading track audio: {err}");
                                tx.send(Err(())).unwrap();
                                break;
                            }
                        }
                    }
                }
                .in_current_span(),
            );

            break Some((rx, mime_type));
        }

        tracing::warn!(
            "received code {} when downloading track audio",
            status.as_u16()
        );

        if IRRECOVERABLE_STATUS_CODES.contains(&status) {
            break None;
        }

        time::sleep(Duration::from_secs(5)).await;
    }
}

pub async fn download_album_cover(
    client: &Client,
    url: &str,
    running: Arc<AtomicBool>,
) -> Option<UnboundedReceiver<Result<Vec<u8>, ()>>> {
    loop {
        let mut response = client.get(url).send().await.unwrap();
        let status = response.status();

        if status == StatusCode::OK {
            let (tx, rx) = mpsc::unbounded_channel();

            tokio::spawn(async move {
                loop {
                    let result = response.chunk().await;

                    match result {
                        Ok(chunk) => match chunk {
                            Some(chunk) => tx.send(Ok(chunk.to_vec())).unwrap(),
                            None => break,
                        },
                        Err(err) => {
                            tracing::warn!("error when downloading album cover: {err}");

                            tx.send(Err(())).unwrap();
                            break;
                        }
                    }
                }
            });

            break Some(rx);
        } else if status == StatusCode::NOT_FOUND {
            tracing::info!("album doesn't have a cover");
            break None;
        }

        tracing::warn!(
            "received code {} when downloading album cover from {url}",
            status.as_u16()
        );

        if !running.load(Ordering::Relaxed) {
            return None;
        }
    }
}
